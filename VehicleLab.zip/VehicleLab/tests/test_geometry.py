import math
import unittest
from vehicle_lab.models import Vehicle, CORNERS
from vehicle_lab import geometry as g
from vehicle_lab.linalg import norm,sub


class GeometryTests(unittest.TestCase):
    def setUp(self):self.v=Vehicle();self.geo=g.default_geometry(self.v)

    def test_static_identity_and_mirror(self):
        w=g.solve_vehicle(self.v,self.geo)
        for c in CORNERS:self.assertLess(w[c]["residual_m"],1e-7)
        self.assertAlmostEqual(w["FL"]["center"][1],-w["FR"]["center"][1])
        self.assertAlmostEqual(w["FL"]["toe_deg"],self.v.toe_front)

    def test_wishbone_constraints_during_bump_and_steer(self):
        for travel in (-.04,.04):
            for rack in (-.02,.02):
                w=g.solve_corner(self.v,self.geo,"FL",travel,rack)
                p=w["points"];base=self.geo["corners"]["FL"]
                for a,b in (("UFI","UBJ"),("URI","UBJ"),("LFI","LBJ"),("LRI","LBJ")):
                    self.assertAlmostEqual(norm(sub(p[a],p[b])),norm(sub(base[a],base[b])),places=6)
                self.assertAlmostEqual(norm(sub(p["ROD_IN"],p["ROD_OUT"])),norm(sub(base["ROD_IN"],base["ROD_OUT"])),places=6)
                self.assertAlmostEqual(w["contact"][2],travel,places=6)

    def test_only_double_wishbone_geometry_is_supported(self):
        self.assertEqual(list(g.TYPES),["double_wishbone"])
        self.assertEqual(set(self.geo),{"types","corners"})
        for points in self.geo["corners"].values():self.assertEqual(set(points),set(g.HARDPOINTS))
        self.geo["types"]["front"]="unsupported"
        with self.assertRaises(ValueError):g.validate_geometry(self.geo)
        with self.assertRaises(ValueError):g.solve_vehicle(self.v,self.geo)

    def test_all_four_corners_and_axle_wrapper(self):
        for travel in (-.04,0,.04):
            wheels=g.solve_vehicle(self.v,self.geo,{c:travel for c in CORNERS})
            self.assertTrue(all(abs(wheels[c]["contact"][2]-travel)<3e-7 for c in CORNERS))
            self.assertIsNotNone(g.roll_center(self.v,self.geo,"front",wheels))
        axle=g.solve_axle(self.v,self.geo,"rear",.02,-.02)
        self.assertAlmostEqual(axle["RL"]["contact"][2],.02,places=6)
        self.assertAlmostEqual(axle["RR"]["contact"][2],-.02,places=6)

    def test_camber_and_toe_static_offsets(self):
        self.v.camber_front=-2;self.v.toe_front=.3
        w=g.solve_vehicle(self.v,self.geo)
        for c in ("FL","FR"):
            self.assertAlmostEqual(w[c]["camber_deg"],-2,places=3)
            self.assertAlmostEqual(w[c]["toe_deg"],.3,places=3)

    def test_roll_center_is_centered(self):
        for axle in ("front","rear"):
            rc=g.roll_center(self.v,self.geo,axle)
            self.assertAlmostEqual(rc[0],0,places=7)
            self.assertTrue(-.5<rc[1]<.5)

    def test_steering_pressure_has_no_effect_in_straight_braking(self):
        a,_,_=g.steering_metrics(self.v,self.geo,ax_g=.8,ay_g=0)
        self.v.pressure_front*=1.5
        b,_,_=g.steering_metrics(self.v,self.geo,ax_g=.8,ay_g=0)
        self.assertAlmostEqual(a[0]["kingpin_Nm"],b[0]["kingpin_Nm"])

    def test_steering_has_ackermann(self):
        rows,_,ack=g.steering_metrics(self.v,self.geo,.025)
        self.assertIsNotNone(ack)
        self.assertGreater(abs(rows[0]["steer_deg"]),2)
        self.assertNotAlmostEqual(rows[0]["steer_deg"],rows[1]["steer_deg"],places=2)

    def test_geometry_goals(self):
        out=g.tune_geometry(self.v,self.geo,"front",.08,20)
        self.assertAlmostEqual(g.roll_center(self.v,out,"front")[1],.08,places=5)
        self.assertAlmostEqual(g.anti_percent(self.v,out,"front"),20,places=3)
        self.assertNotEqual(out,self.geo)

    def test_kingpin_goals(self):
        out=g.set_kingpin_goals(self.v,self.geo,"front",.03,.035)
        rows,_,_=g.steering_metrics(self.v,out)
        self.assertAlmostEqual(rows[0]["scrub_mm"],30,places=5)
        self.assertAlmostEqual(rows[1]["trail_mm"],35,places=5)

    def test_reverse_ackermann_sign(self):
        self.assertLess(g.ackermann_percent(10,20,2.5,1.5),0)
        self.assertGreater(g.ackermann_percent(20,10,2.5,1.5),0)

    def test_fsae_nominal_roll_centers_and_sweep(self):
        self.assertAlmostEqual(g.roll_center(self.v,self.geo,"front")[1],.0400223065,places=6)
        self.assertAlmostEqual(g.roll_center(self.v,self.geo,"rear")[1],.0499934637,places=6)
        self.assertTrue(all(row["status"]=="ok" for row in g.geometry_sweep(self.v,self.geo,.04,9)))

    def test_acceleration_loads_follow_front_rear_reduction_gain(self):
        self.v.reduction_front=8
        self.v.reduction_rear=12
        rows,_,_=g.steering_metrics(self.v,self.geo,ax_g=-.5,ay_g=0)
        # With equal efficiencies/radii, front and rear torque fractions are 0.4/0.6.
        # At zero lateral force the moment is exactly Fx times scrub.
        for i,row in enumerate(rows):
            fraction=.4 if i<2 else .6
            fx=self.v.mass*9.80665*.5*fraction/2
            self.assertAlmostEqual(row["kingpin_Nm"],fx*row["scrub_mm"]/1000,places=6)
