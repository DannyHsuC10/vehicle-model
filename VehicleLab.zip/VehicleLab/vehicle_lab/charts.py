"""Offline Tk canvas charts with pan/zoom, SVG and optional Pillow PNG export."""
import html
import math
import tkinter as tk
from tkinter import ttk
from pathlib import Path

COLORS=("#38bdf8","#fbbf24","#a78bfa","#34d399","#fb7185","#fb923c")
BG="#0f172a"


class Chart(ttk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0,width=800,height=470)
        self.canvas.pack(fill="both",expand=True)
        self.spec=None; self.primitives=[]; self.view=None; self.drag=None
        self.azimuth=-.65; self.elevation=.5
        self.canvas.bind("<Configure>",lambda event:self.draw())
        self.canvas.bind("<MouseWheel>",self.zoom)
        self.canvas.bind("<Button-1>",lambda e:setattr(self,"drag",(e.x,e.y)))
        self.canvas.bind("<B1-Motion>",self.pan)
        self.canvas.bind("<Double-Button-1>",lambda e:self.reset())
        self.canvas.bind("<Motion>",self.hover)

    def set(self,spec):
        self.spec=spec; self.view=None; self.draw()

    def reset(self):
        self.view=None; self.draw()

    def line(self,coords,color,width=1):
        self.canvas.create_line(*coords,fill=color,width=width)
        self.primitives.append(("line",list(coords),color,width))

    def text(self,x,y,text,color="#cbd5e1",size=10,anchor="center"):
        self.canvas.create_text(x,y,text=str(text),fill=color,font=("Microsoft JhengHei UI",size),anchor=anchor)
        self.primitives.append(("text",[x,y],color,size,str(text),anchor))

    def project(self,point,projection):
        x,y,z=point
        if projection=="Front": return -y,z
        if projection=="Rear": return y,z
        if projection=="Side": return x,z
        if projection=="Top": return -y,x
        ca,sa=math.cos(self.azimuth),math.sin(self.azimuth)
        ce,se=math.cos(self.elevation),math.sin(self.elevation)
        return x*ca-y*sa, z*ce-(x*sa+y*ca)*se

    def draw(self):
        self.canvas.delete("all"); self.primitives=[]
        width=max(self.canvas.winfo_width(),300); height=max(self.canvas.winfo_height(),220)
        spec=self.spec
        if not spec:
            self.text(width/2,height/2,"設定參數後按「計算」",size=15)
            return
        series=spec.get("series",[])
        if "segments" in spec:
            projection=spec.get("projection","Iso")
            lookup={"upper":"#fbbf24","lower":"#38bdf8","upright":"#a78bfa","rod":"#fb923c","wheel":"#d1d5db"}
            series=[{"name":kind,"x":[self.project(a,projection)[0],self.project(b,projection)[0]],
                     "y":[self.project(a,projection)[1],self.project(b,projection)[1]],"color":lookup[kind]}
                    for a,b,kind in spec["segments"]]
        pairs=[(x,y) for s in series for x,y in zip(s["x"],s["y"]) if self.finite(x) and self.finite(y)]
        if not pairs:
            self.text(width/2,height/2,"沒有可繪製的數值（可能為飽和或幾何不可達）")
            return
        left,top,right,bottom=85,64,width-35,height-67
        pw,ph=max(right-left,1),max(bottom-top,1)
        if self.view is None:
            xs,ys=zip(*pairs); xmin,xmax=min(xs),max(xs); ymin,ymax=min(ys),max(ys)
            dx=xmax-xmin or max(abs(xmax)*.2,1); dy=ymax-ymin or max(abs(ymax)*.2,1)
            xmin-=dx*.06; xmax+=dx*.06; ymin-=dy*.12; ymax+=dy*.12
            if spec.get("equal") or "segments" in spec:
                ratio=pw/ph
                if (xmax-xmin)/(ymax-ymin)<ratio:
                    mid=(xmin+xmax)/2; span=(ymax-ymin)*ratio; xmin,xmax=mid-span/2,mid+span/2
                else:
                    mid=(ymin+ymax)/2; span=(xmax-xmin)/ratio; ymin,ymax=mid-span/2,mid+span/2
            self.view=[xmin,xmax,ymin,ymax]
        xmin,xmax,ymin,ymax=self.view
        self.bounds=(left,top,right,bottom)
        sx=lambda x:left+(x-xmin)/(xmax-xmin)*pw
        sy=lambda y:bottom-(y-ymin)/(ymax-ymin)*ph
        for i in range(6):
            x=left+pw*i/5; y=top+ph*i/5
            self.line([x,top,x,bottom],"#253247")
            self.line([left,y,right,y],"#253247")
            self.text(x,bottom+17,f"{xmin+(xmax-xmin)*i/5:.4g}",size=9)
            self.text(left-10,y,f"{ymax-(ymax-ymin)*i/5:.4g}",anchor="e",size=9)
        if ymin<0<ymax: self.line([left,sy(0),right,sy(0)],"#64748b")
        if xmin<0<xmax: self.line([sx(0),top,sx(0),bottom],"#64748b")
        self.text(left,22,spec.get("title",""),"#f8fafc",14,"w")
        self.text((left+right)/2,height-19,spec.get("xlabel",""),size=10)
        self.text(10,42,spec.get("ylabel",""),"#94a3b8",9,"w")
        legend=[]
        for index,s in enumerate(series):
            color=s.get("color",COLORS[index%len(COLORS)])
            name=s.get("name","")
            if name and name not in [a[0] for a in legend]: legend.append((name,color))
            last=None
            for x,y in zip(s["x"],s["y"]):
                if not self.finite(x) or not self.finite(y): last=None; continue
                point=(sx(x),sy(y))
                if last is not None:
                    clipped=self.clip(last,point,left,top,right,bottom)
                    if clipped: self.line(clipped,color,2)
                last=point
        # Legend above the plotting area; truncate labels to prevent overflow.
        xpos=left
        for label,color in legend[:6]:
            self.line([xpos,45,xpos+17,45],color,3)
            text=label[:25]
            self.text(xpos+23,45,text,color,9,"w")
            xpos+=max(90,len(text)*6.5+36)
        self.text(right,bottom+38,"滾輪縮放 · 拖曳平移 / 立體旋轉 · 雙擊重設",color="#64748b",size=8,anchor="e")

    @staticmethod
    def finite(x): return isinstance(x,(float,int)) and math.isfinite(x)

    @staticmethod
    def clip(a,b,l,t,r,bot):
        x,y=a; dx=b[0]-x; dy=b[1]-y; low,high=0.,1.
        for p,q in ((-dx,x-l),(dx,r-x),(-dy,y-t),(dy,bot-y)):
            if abs(p)<1e-12:
                if q<0: return None
            elif p<0: low=max(low,q/p)
            else: high=min(high,q/p)
            if low>high: return None
        return [x+low*dx,y+low*dy,x+high*dx,y+high*dy]

    def zoom(self,event):
        if self.view is None: return
        factor=.85 if event.delta>0 else 1/.85
        xmin,xmax,ymin,ymax=self.view
        l,t,r,b=self.bounds
        px=max(0,min(1,(event.x-l)/max(r-l,1))); py=max(0,min(1,(b-event.y)/max(b-t,1)))
        cx=xmin+(xmax-xmin)*px; cy=ymin+(ymax-ymin)*py
        self.view=[cx+(xmin-cx)*factor,cx+(xmax-cx)*factor,cy+(ymin-cy)*factor,cy+(ymax-cy)*factor]
        self.draw()

    def pan(self,event):
        if self.drag is None or self.view is None: return
        dx,dy=event.x-self.drag[0],event.y-self.drag[1]
        self.drag=(event.x,event.y)
        if self.spec and self.spec.get("projection")=="Iso":
            self.azimuth+=dx*.01; self.elevation=max(-1.3,min(1.3,self.elevation+dy*.01)); self.view=None
        else:
            xmin,xmax,ymin,ymax=self.view; l,t,r,b=self.bounds
            sx=dx*(xmax-xmin)/max(r-l,1); sy=dy*(ymax-ymin)/max(b-t,1)
            self.view=[xmin-sx,xmax-sx,ymin+sy,ymax+sy]
        self.draw()

    def hover(self,event):
        self.canvas.delete("cursor")
        if self.view is None or not hasattr(self,"bounds"): return
        l,t,r,b=self.bounds
        if not l<event.x<r or not t<event.y<b: return
        xmin,xmax,ymin,ymax=self.view
        x=xmin+(event.x-l)/(r-l)*(xmax-xmin)
        y=ymax-(event.y-t)/(b-t)*(ymax-ymin)
        self.canvas.create_text(r-5,t+14,text=f"x={x:.5g}   y={y:.5g}",fill="#f8fafc",anchor="e",font=("Segoe UI",9),tags="cursor")

    def svg(self):
        width=max(self.canvas.winfo_width(),300); height=max(self.canvas.winfo_height(),220)
        elements=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
                  f'<rect width="100%" height="100%" fill="{BG}"/>']
        for item in self.primitives:
            kind,xy,color,size,*rest=item
            if kind=="line":
                coords=" ".join(f"{xy[i]:.2f},{xy[i+1]:.2f}" for i in range(0,len(xy),2))
                elements.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="{size}"/>')
            else:
                content,anchor=rest
                alignment="end" if anchor=="e" else "start" if anchor=="w" else "middle"
                elements.append(f'<text x="{xy[0]:.2f}" y="{xy[1]+size*.4:.2f}" fill="{color}" font-size="{size*1.3}" font-family="Microsoft JhengHei UI, sans-serif" text-anchor="{alignment}">{html.escape(content)}</text>')
        return "\n".join(elements+["</svg>"])

    def png(self,path):
        try:
            from PIL import Image,ImageDraw,ImageFont
        except ImportError as exc:
            raise ValueError("PNG 需要選用套件 Pillow：python -m pip install Pillow。SVG 不需套件。") from exc
        factor=2
        width=max(self.canvas.winfo_width(),300); height=max(self.canvas.winfo_height(),220)
        image=Image.new("RGB",(width*factor,height*factor),BG); draw=ImageDraw.Draw(image)
        font_path=Path("C:/Windows/Fonts/msjh.ttc")
        for item in self.primitives:
            kind,xy,color,size,*rest=item
            scaled=[x*factor for x in xy]
            if kind=="line": draw.line(scaled,fill=color,width=max(1,int(size*factor)))
            else:
                text,anchor=rest
                font=ImageFont.truetype(str(font_path),int(size*1.3*factor)) if font_path.exists() else ImageFont.load_default()
                align="rm" if anchor=="e" else "lm" if anchor=="w" else "mm"
                draw.text(scaled,text,fill=color,font=font,anchor=align)
        image.save(path)
